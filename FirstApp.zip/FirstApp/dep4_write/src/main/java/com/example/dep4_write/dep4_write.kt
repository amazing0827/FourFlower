package com.example.dep4_write

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class dep4_write : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dep4_write)
    }
}