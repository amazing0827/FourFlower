pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "FirstApp"
include(":app")
include(":dep2_menu")
include(":dep4_write")
include(":dep4_search_car")
include(":dep4_add_car")
include(":dep4_add_car")
include(":dep4-newvote")
include(":dep3_secession")
include(":dep4_other_post")
