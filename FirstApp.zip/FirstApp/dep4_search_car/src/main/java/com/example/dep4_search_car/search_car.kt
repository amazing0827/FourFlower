package com.example.dep4_search_car

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class search_car : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search_car)
    }
}